% Ian Kleckner
% 2017/10/02
% 2019/06/12 Update name of program

% Run the task starter program upon starting in this directory
Task_Starter
